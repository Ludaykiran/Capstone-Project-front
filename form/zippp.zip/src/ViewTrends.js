import React from 'react';
import { useSelector } from 'react-redux';
import { Bar } from 'react-chartjs-2';
import './style.css';
const ViewTrends = () => {
  const workouts = useSelector(state => state.workouts);

  const data = {
    labels: workouts.map((workout, index) => `Workout ${index + 1}`),
    datasets: [
      {
        label: 'Workout Duration (mins)',
        data: workouts.map(workout => workout.duration),
        backgroundColor: 'rgba(75,192,192,0.6)',
      },
    ],
  };

  return (
    <div>
      <h2>Workout Trends</h2>
      <Bar data={data} />
    </div>
  );
};

export default ViewTrends;