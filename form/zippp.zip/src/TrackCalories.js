// import React, { useState } from 'react';
// import { useDispatch, useSelector } from 'react-redux';
// import { logCalorie } from './calorieSlice';

// const TrackCalories = () => {
//   const dispatch = useDispatch();
//   const calories = useSelector(state => state.calories);
//   const [foodItem, setFoodItem] = useState('');
//   const [caloriesCount, setCaloriesCount] = useState('');

//   const handleLogCalorie = () => {
//     if (foodItem && caloriesCount) {
//       dispatch(logCalorie({ food: foodItem, calories: Number(caloriesCount) }));
//       setFoodItem('');
//       setCaloriesCount('');
//     }
//   };

//   return (
//     <div>
//       <h2>Track Calories</h2>
//       <input type='text' value={foodItem} onChange={(e) => setFoodItem(e.target.value)} placeholder='Food Item' />
//       <input type='number' value={caloriesCount} onChange={(e) => setCaloriesCount(e.target.value)} placeholder='Calories' />
//       <button onClick={handleLogCalorie}>Log Calorie</button>
      
//       <ul>
//         {calories.map((entry, index) => (
//           <li key={index}>{entry.food} - {entry.calories} kcal</li>
//         ))}
//       </ul>
//     </div>
//   );
// };

// export default TrackCalories;
import React, { useState, useEffect, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { logCalorie } from './calorieSlice';
import './style.css';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from 'chart.js';

import { Bar } from 'react-chartjs-2';

// Register required Chart.js components
ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

const TrackCalories = () => {
  const dispatch = useDispatch();
  const calories = useSelector(state => state.calories);
  const [foodItem, setFoodItem] = useState('');
  const [caloriesCount, setCaloriesCount] = useState('');
  const chartRef = useRef(null);
  let myChart = useRef(null);

  const handleLogCalorie = () => {
    if (foodItem && caloriesCount) {
      dispatch(logCalorie({ food: foodItem, calories: Number(caloriesCount) }));
      setFoodItem('');
      setCaloriesCount('');
    }
  };

  // Prepare data for the chart
  const chartData = {
    labels: calories.map(entry => entry.food),
    datasets: [
      {
        label: 'Calories',
        data: calories.map(entry => entry.calories),
        backgroundColor: 'rgba(75, 192, 192, 0.6)',
        borderColor: 'rgba(75, 192, 192, 1)',
        borderWidth: 1,
      },
    ],
  };

  useEffect(() => {
    if (chartRef.current) {
      if (myChart.current) {
        myChart.current.destroy(); // Destroy old chart instance before creating a new one
      }

      myChart.current = new ChartJS(chartRef.current, {
        type: 'bar',
        data: chartData,
        options: {
          responsive: true,
          plugins: {
            legend: { display: false },
            title: { display: true, text: 'Calorie Chart' },
          },
        },
      });
    }

    return () => {
      if (myChart.current) {
        myChart.current.destroy(); // Cleanup when component unmounts
      }
    };
  }, [calories]); // Redraw when `calories` state updates

  return (
    <div>
      <h2>Track Calories</h2>
      <input
        type='text'
        value={foodItem}
        onChange={(e) => setFoodItem(e.target.value)}
        placeholder='Food Item'
      />
      <input
        type='number'
        value={caloriesCount}
        onChange={(e) => setCaloriesCount(e.target.value)}
        placeholder='Calories'
      />
      <button onClick={handleLogCalorie}>Log Calorie</button>

      <ul>
        {calories.map((entry, index) => (
          <li key={index}>
            {entry.food} - {entry.calories} kcal
          </li>
        ))}
      </ul>

      {/* Chart Section */}
      <canvas ref={chartRef} />
    </div>
  );
};

export default TrackCalories;
