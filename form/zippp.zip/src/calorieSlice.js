import { createSlice } from '@reduxjs/toolkit';

const calorieSlice = createSlice({
  name: 'calories',
  initialState: [],
  reducers: {
    logCalorie: (state, action) => {
      state.push(action.payload);
    },
  },
});

export const { logCalorie } = calorieSlice.actions;
export default calorieSlice.reducer;