import { createSlice } from '@reduxjs/toolkit';
const workoutSlice = createSlice({
  name: 'workouts',
  initialState: [],
  reducers: {
    addWorkout: (state, action) => {
      state.push(action.payload);
    },
  },
});

export const { addWorkout } = workoutSlice.actions;
export default workoutSlice.reducer;