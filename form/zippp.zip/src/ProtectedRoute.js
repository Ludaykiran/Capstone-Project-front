// import React from "react";
// import { Navigate, Outlet } from "react-router-dom";

// const ProtectedRoute =(props) => {
//     return(
//         props.isAuthenticated ? <Outlet></Outlet> : <Navigate to='/'></Navigate> 
//     );
// }

// export default ProtectedRoute;
import React from "react";
import { Navigate, Outlet } from "react-router-dom";

const ProtectedRoute = () => {
  const isAuthenticated = localStorage.getItem("authToken"); // ✅ Check if token exists

  return isAuthenticated ? <Outlet /> : <Navigate to="/login" replace />;
};

export default ProtectedRoute;
