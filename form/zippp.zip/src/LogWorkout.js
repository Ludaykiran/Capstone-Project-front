import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { addWorkout } from './workoutSlice';
import './style.css';
const LogWorkout = () => {
  const dispatch = useDispatch();
  const workouts = useSelector(state => state.workouts);
  const [workoutType, setWorkoutType] = useState('');
  const [duration, setDuration] = useState('');

  const handleAddWorkout = () => {
    if (workoutType && duration) {
      dispatch(addWorkout({ type: workoutType, duration: Number(duration) }));
      setWorkoutType('');
      setDuration('');
    }
  };

  return (
    <div>
      <h2>Log Workout</h2>
      <input type='text' value={workoutType} onChange={(e) => setWorkoutType(e.target.value)} placeholder='Workout Type' />
      <input type='number' value={duration} onChange={(e) => setDuration(e.target.value)} placeholder='Duration (mins)' />
      <button onClick={handleAddWorkout}>Add Workout</button>
      
      <ul>
        {workouts.map((workout, index) => (
          <li key={index}>{workout.type} - {workout.duration} mins</li>
        ))}
      </ul>
    </div>
  );
};

export default LogWorkout;